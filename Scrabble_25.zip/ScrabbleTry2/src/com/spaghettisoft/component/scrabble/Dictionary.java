package com.spaghettisoft.component.scrabble;

public class Dictionary {

	public static String[] validWords2letters = {};

	public static String[] validWords3letters = {};

	public static String[] validWords4letters = {};

	public static String[] validWords5letters = {"Aback"};

	public static String[] validWords6letters = {"Abacus"};

	public static String[] validWords7letters = {"Aardvark"};

	public static String[] validWords8letters = {};

	public static String[] validWords9letters = {};

	public static String[] validWords10letters = {};

	public static String[] validWords11letters = {};

	public static String[] validWords12letters = {};

	public static String[] validWords13letters = {};

	public static String[] validWords14letters = {};

	public static String[] validWords15letters = {};







}
